const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const FILE_PATH = path.join(__dirname, "lembretes.json");

// Rota para salvar lembrete
app.post("/api/lembrete", (req, res) => {
  let lembretes = [];
  try {
    const data = fs.existsSync(FILE_PATH)
      ? fs.readFileSync(FILE_PATH, "utf8")
      : "";
    lembretes = data ? JSON.parse(data) : [];
  } catch (err) {
    lembretes = [];
  }

  lembretes.push(req.body);
  fs.writeFileSync(FILE_PATH, JSON.stringify(lembretes, null, 2));
  res.json({ message: "Lembrete salvo com sucesso!" });
});

// Rota para listar lembretes
app.get("/api/lembretes", (req, res) => {
  let lembretes = [];
  try {
    const data = fs.existsSync(FILE_PATH)
      ? fs.readFileSync(FILE_PATH, "utf8")
      : "";
    lembretes = data ? JSON.parse(data) : [];
  } catch (err) {
    lembretes = [];
  }
  res.json(lembretes);
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
