const form = document.getElementById("reminderForm");
const list = document.getElementById("reminderList");

async function loadReminders() {
  const res = await fetch("/api/lembretes");
  const reminders = await res.json();
  list.innerHTML = "";
  const now = new Date().getTime();

  reminders.forEach((r) => {
    let item = document.createElement("div");
    item.className = "reminder";

    const dateOptions = { day: "2-digit", month: "2-digit" };

    let lembreteTime = new Date(r.dateLembrete).getTime();
    let medicamentoFormatado = new Date(r.dateMedicamento).toLocaleDateString(
      "pt-BR",
      dateOptions
    );

    let content = `<strong>${r.name}</strong> - ${r.medicamento}<br>
              Data do lembrete: ${new Date(r.dateLembrete).toLocaleString()}<br>
               Data do uso do medicamento: ${medicamentoFormatado}<br>`;

    if (lembreteTime <= now) {
      let msg = encodeURIComponent(
        `Olá ${r.name}, lembrete do uso seu medicamento: ${r.medicamento} para o dia ${medicamentoFormatado}`
      );
      content += `<a class="whatsapp-btn" href="https://wa.me/${r.phone}?text=${msg}" target="_blank">Enviar no WhatsApp</a>`;
    } else {
      content += `<small>Aguardando data do lembrete</small>`;
    }

    item.innerHTML = content;
    list.appendChild(item);
  });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = {
    name: document.getElementById("name").value,
    medicamento: document.getElementById("medicamento").value,
    dateLembrete: document.getElementById("dateLembrete").value,
    dateMedicamento: document.getElementById("dateMedicamento").value,
    phone: document.getElementById("phone").value,
  };

  await fetch("/api/lembrete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  form.reset();
  loadReminders();
});

setInterval(loadReminders, 5000);
loadReminders();
